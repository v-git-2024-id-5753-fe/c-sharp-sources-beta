﻿namespace Kalan.PWM.Logger
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ButtonOpenPort = new System.Windows.Forms.Button();
            this.TextBoxPortName = new System.Windows.Forms.TextBox();
            this.TextBoxPortSpeed = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // ButtonOpenPort
            // 
            this.ButtonOpenPort.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonOpenPort.Location = new System.Drawing.Point(13, 13);
            this.ButtonOpenPort.Name = "ButtonOpenPort";
            this.ButtonOpenPort.Size = new System.Drawing.Size(120, 60);
            this.ButtonOpenPort.TabIndex = 0;
            this.ButtonOpenPort.Text = "Open Port";
            this.ButtonOpenPort.UseVisualStyleBackColor = true;
            this.ButtonOpenPort.Click += new System.EventHandler(this.ButtonOpenPort_Click);
            // 
            // TextBoxPortName
            // 
            this.TextBoxPortName.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxPortName.Location = new System.Drawing.Point(13, 79);
            this.TextBoxPortName.Name = "TextBoxPortName";
            this.TextBoxPortName.Size = new System.Drawing.Size(120, 25);
            this.TextBoxPortName.TabIndex = 1;
            this.TextBoxPortName.Text = "COM22";
            // 
            // TextBoxPortSpeed
            // 
            this.TextBoxPortSpeed.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxPortSpeed.Location = new System.Drawing.Point(13, 110);
            this.TextBoxPortSpeed.Name = "TextBoxPortSpeed";
            this.TextBoxPortSpeed.Size = new System.Drawing.Size(120, 25);
            this.TextBoxPortSpeed.TabIndex = 2;
            this.TextBoxPortSpeed.Text = "123";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(437, 158);
            this.Controls.Add(this.TextBoxPortSpeed);
            this.Controls.Add(this.TextBoxPortName);
            this.Controls.Add(this.ButtonOpenPort);
            this.Name = "MainForm";
            this.Text = "USB_VCP_Template";
            this.Load += new System.EventHandler(this.MainFormLoad);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ButtonOpenPort;
        private System.Windows.Forms.TextBox TextBoxPortName;
        private System.Windows.Forms.TextBox TextBoxPortSpeed;
    }
}

