﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_Forms_Textbox_output
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int MinWidth = 400;
        int MinHeigh = 200;
        // 2024.03.25 09:23. Ratio with 1.6 looks good. there is ratio 16:9 that is widely spreaded.
        private void Form1_Load(object sender, EventArgs e)
        {
            
            
            textBox1.Location = new Point(0, 0);
            textBox1.Size = this.ClientSize;
            for (int i = 0; i < 50; i++)
            {


                textBox1.Text += "ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff";
                textBox1.Text += "\r\n";
            }
            
            
        }

        private void Form1_SizeChanged(object sender, EventArgs e)
        {
            this.SizeChanged -= Form1_SizeChanged;
            

            Size size_set = this.ClientSize;
            
            if (size_set.Width < MinWidth)
            {
                size_set.Width = MinWidth;
                
            }

            if (size_set.Height < MinHeigh)
            {
                size_set.Height = MinHeigh;
               
            }
            this.ClientSize = size_set;
            textBox1.Size = size_set;
            this.SizeChanged += Form1_SizeChanged;

        }
    }
}
