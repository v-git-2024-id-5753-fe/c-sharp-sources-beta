﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_Forms_Textbox_output
{
    public class Form_TextBox_TextShow : Form
    {

        

        /// <summary>
        /// 2024.03.25 11:59. Moscow. Workplace. 
        /// It should be placed is contructor or form load
        /// </summary>
        /// <param name="name_in"></param>
        public Form_TextBox_TextShow(string name_in)
        {
            Form_Constructor_Function(name_in);
            this.Show();

        }

        


            public void Form_Constructor_Function(string name_in)
        {
            this.TextBox_Output = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.TextBox_Output.BackColor = System.Drawing.Color.Black;
            this.TextBox_Output.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TextBox_Output.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextBox_Output.ForeColor = System.Drawing.Color.White;
            this.TextBox_Output.Location = new System.Drawing.Point(0, 0);
            //this.TextBox_Output.Margin = new System.Windows.Forms.Padding(4);
            this.TextBox_Output.Multiline = true;
            this.TextBox_Output.Name = "textBox_text_show";
            this.TextBox_Output.ReadOnly = true;
            this.TextBox_Output.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TextBox_Output.Size = new System.Drawing.Size(100, 100);
            this.TextBox_Output.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(914, 519);
            this.Controls.Add(this.TextBox_Output);
            this.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form_TextBox_TextShow_Load);
            this.SizeChanged += new System.EventHandler(this.Form1_SizeChanged);
            this.ResumeLayout(false);
            this.PerformLayout();
            this.Text = name_in;
        }

        // note. 2024.03.25 09:40. Moscow. Workplace.
        // textbox wrap the text to 2 lines if there is not enough space.
        // it makes 1 line of text from text on 2 lines.

        // 2024.03.25 09:40. Moscow.
        // 1. Min size during autoresize. ration 2/1.
        // 2. scroll bar
        // 3. background color.


        private System.Windows.Forms.TextBox TextBox_Output;

        int MinWidth = 400;
        int MinHeigh = 200;

        // 2024.03.25 09:23. Moscow. Workplace. Ratio with 1.6 looks good. there is ratio 16:9 that is widely spreaded.
        private void Form_TextBox_TextShow_Load(object sender, EventArgs e)
        {
            TextBox_Output.Location = new Point(0, 0);
            TextBox_Output.Size = this.ClientSize;
        }

        public void Clear()
        {
            TextBox_Output.Text = "";
        }

        public void Write(string text_in)
        {
            string text_current = TextBox_Output.Text;
            text_current += text_in;
            TextBox_Output.Text = text_current;
            TextBox_Output.SelectionStart = TextBox_Output.Text.Length;
            TextBox_Output.ScrollToCaret();
        }

        public void WriteLine(string text_in)
        {
            string text_current = TextBox_Output.Text;
            text_current += text_in + "\r\n";
            TextBox_Output.Text = text_current;
            TextBox_Output.SelectionStart = TextBox_Output.Text.Length;
            TextBox_Output.ScrollToCaret();
        }

        // 2024.03.25 09:42. Moscow. Workplace.
        // glitching windows is seen when set min size. the textbox 1st is made smaller and then made to be with min size
        // it is all drawn
        private void Form1_SizeChanged(object sender, EventArgs e)
        {
            this.SizeChanged -= Form1_SizeChanged;

            Size size_set = this.ClientSize;

            if (size_set.Width < MinWidth)
            {
                size_set.Width = MinWidth;
            }

            if (size_set.Height < MinHeigh)
            {
                size_set.Height = MinHeigh;
            }
            this.ClientSize = size_set;
            TextBox_Output.Size = size_set;
            this.SizeChanged += Form1_SizeChanged;
        }

    }
}
