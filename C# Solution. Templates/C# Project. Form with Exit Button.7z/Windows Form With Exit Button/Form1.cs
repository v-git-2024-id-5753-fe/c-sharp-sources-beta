﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {           
            Button_Exit.Location = new Point(this.ClientSize.Width - Button_Exit_Offset - Button_Exit.Size.Width, Button_Exit_Offset);
        }

        const int Button_Exit_Offset = 25;
       
        private void Button_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
