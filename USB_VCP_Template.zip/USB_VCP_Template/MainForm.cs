﻿
using Kalan.PWM.Logger.Properties;
using MyUSBMethodsNamespace;
using System;
using System.Windows.Forms;


namespace Kalan.PWM.Logger
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
        string debug1 = "";
        private void MainFormLoad(object sender, EventArgs e)
        {
            TextBoxPortName.Text = Settings.Default.PortName; 
         
            TextBoxPortSpeed.Text = Settings.Default.PortSpeed.ToString();
            TextBoxPortName.TextChanged += TextBoxPortName_TextChanged;
            TextBoxPortSpeed.TextChanged += TextBoxPortSpeed_TextChanged;
        }

        private void TextBoxPortName_TextChanged(object sender, EventArgs e)
        {
            Settings.Default.PortName = TextBoxPortName.Text;
            Settings.Default.Save();
        }

        private void TextBoxPortSpeed_TextChanged(object sender, EventArgs e)
        {
            Settings.Default.PortSpeed = System.Convert.ToInt32(TextBoxPortSpeed.Text);
            Settings.Default.Save();
        }

        USB_as_VCP UARTPort = null; 
        enum ButtonState
        {
            NotDefined,
            Clicked,
            NotClicked
        }
        ButtonState ButtonOpenPortState = ButtonState.NotClicked;
        private void ButtonOpenPort_Click(object sender, EventArgs e)
        {
            if (ButtonOpenPortState == ButtonState.NotClicked)
            {
                UARTPort = new USB_as_VCP(TextBoxPortName.Text, System.Convert.ToInt32(TextBoxPortSpeed.Text), this);
                try
                {
                    UARTPort.Open();
                    if (UARTPort.IsOpen == true)
                    {
                        Console.WriteLine("Port is opened");
                    }
                    else
                    {
                        Console.WriteLine("Port is not opened");
                    }
                }
                catch
                {
                    Console.WriteLine("Failure. Port was not opened");
                }
                ButtonOpenPortState = ButtonState.Clicked;
                ButtonOpenPort.Text = "Close Port";
                return;
            }

            if (ButtonOpenPortState == ButtonState.Clicked)
            {                
                try
                {
                    UARTPort.Close();
                    if (UARTPort.IsOpen == false)
                    {
                        Console.WriteLine("Port is closed");
                        ButtonOpenPortState = ButtonState.NotClicked;
                        ButtonOpenPort.Text = "Open Port";
                    }
                    else
                    {
                        Console.WriteLine("Port was not closed");
                    }
                }
                catch
                {
                    Console.WriteLine("Failure. Port was closed");
                }                
                return;
            }



        }
    }
}
